<?php

$_['ord_desc_title'] = 'Description';
$_['ord_price_title'] = 'Price';
$_['text_info']      = 'Payment with DIBS Flex Win';
$_['button_confirm'] = 'Confirm';