If you have vQmod in your Opencart please don't use this module.
Use module that works with vQmod:
VQmod/opencart_2.0.x_dibs_flexwin_vqm_3.0.3.zip