<?php 
// Heading
$_['heading_title']    = 'DIBS invoice fee';

$_['entry_status']     = 'Ststus';

$_['entry_sort_order']  = 'Sort order';

$_['text_edit']         = 'Edit Dibsinvoice fee';